#!/bin/bash

#diferentes feriados del 2023, en el formato fecha se muestra primero el mes y luego el dia"


comprobarLaborable()
{
	fecha=$1
	feriados=("2023-01-01" "2023-03-24" "2023-04-02" "2023-05-01" "2023-05-25" "2023-06-20" "2023-07-09" "2023-08-17" "2023-10-12" "2023-16-10" "2023-12-8" "2023-25-12")
	diaDeLaSemana=$(date -d "$fecha" +%u)
	diaDelMes=$(date -d "$fecha" +%m-%d)
	Indice=0
	sizeDelArreglo=${#feriados[@]}

#Comprueba si la fecha se encuentra dentro del final de la semana lo cual es igual a que no sea laborable"

	if [ $diaDeLaSemana -eq 6 ] || [ $diaDeLaSemana -eq 7 ]; then
		echo "La fecha en cuestion $fecha es parte del final de la semana, por ende no es laborable"
		return 1
	fi

#Comprueba si la fecha ingresada es un feriado a traves de un ciclo while

encontrado=false
i=0

while [ $i -lt ${#feriados[@]} ]; do
	if [ "${feriados[i]}" = "$fecha" ]; then
		encontrado=true
		break
	fi
	((i++))
done

#Cuando se produce un acierto
if $encontrado; then
	echo "La fecha $fecha es un feriado y no es laborable"
	return 1
fi

#Cuando no es ni finde ni feriado, es laborable. Entonces:

echo "La fecha $fecha es laborable"
return 1



}
