#!/bin/sh

#verifica si la cantidad de procesos es distinta de 1 

if [ $# -ne 1 ]; then
	echo "Uso: $0 <nombreDelProceso>"
	exit 1
fi
proceso="$1"
if pgrep -x "$proceso" >/dev/null; then
	echo "El proceso $proceso se esta ejecutando" > /dev/null
#A modo de verificacion, me mando al mail tambien si el caso es afirmativo, como verificacion extra
	echo "El proceso $proceso Si se encuentra en ejecucion :D" | mutt -s "anda perfecto :D" root
	echo
else
	email_asunto="Error: Proceso $proceso no esta en ejecucion"
	email_chat="El proceso $proceso no se esta ejecutando"
	echo "$email_chat" | mutt -s "$email_asunto" root

fi
