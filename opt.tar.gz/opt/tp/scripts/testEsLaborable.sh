#!/bin/bash

#Comprobar si el dia ingresado es un feriado o un fin de semana. Algunos ejemplos

source esLaborable.sh

comprobarLaborable "2023-09-02"
comprobarLaborable "2023-05-01"
comprobarLaborable "2023-10-12"
comprobarLaborable "2023-05-16"
comprobarLaborable "2023-02-15"
comprobarLaborable "2023-11-16"
