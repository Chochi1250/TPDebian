#!/bin/bash


entrada=""
salida=""


Ayuda ()
{
	echo "Para el uso del backup_full.sh: -e directorioDeEntrada -s directorioDeSalida"
	echo "-e para el directorio de entrada (lo que quiero mandar)"
	echo "-s para el directorio de salida (lo que quiero guardar)"
	echo "-a sirve para mostrar comandos para utilizar el script"
	exit 1 	
}


fecha=$(date "+%Y%m%d")
tiempo=$(date "+%H:%M:%S")

msgLog()
{
	local msg="$1"
	echo "$fecha - $tiempo - $msg" >> "/var/log/backup_full.log"
}


while getopts "e:s:a" opt; do
	case $opt in
	e) entrada="$OPTARG";;
	s) salida="$OPTARG";;
	a) Ayuda;;
	\?) echo "Error 404, algo fallo" >&2; exit 1;;
	esac
done

if [ -z "$entrada" ] || [ -z "$salida" ]; then
	echo "Error, se tiene que ingresar un directorio de entrada y luego otro de salida"
	echo "Aqui tiene los comandos para guiarse"
	Ayuda
fi


if [ ! -d "$entrada" ] || [ ! -d "$salida" ]; then
	echo "Error, directorios ingresados no validos. Pruebe nuevamente"
	exit 1
fi


archivo="$(basename $entrada)_bkp_${fecha}.tar.gz"

msgLog "se solicito un backup para $entrada y se guardara en $salida"
tar czf "${salida}/${archivo}" "$entrada" && msgLog "backup realizado con exito :D" || msgLog "Error al realizar el backup D:"

echo "El archivo en cuestion:" | mutt -s "archivoLog" -a /var/log/backup_full.log -- root



